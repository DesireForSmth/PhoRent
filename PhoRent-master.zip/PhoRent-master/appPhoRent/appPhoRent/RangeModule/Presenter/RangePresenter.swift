//
//  RangePresenter.swift
//  appPhoRent
//
//  Created by Ilya Buzyrev on 19.04.2020.
//  Copyright © 2020 Александр Сетров. All rights reserved.
//

import Foundation
