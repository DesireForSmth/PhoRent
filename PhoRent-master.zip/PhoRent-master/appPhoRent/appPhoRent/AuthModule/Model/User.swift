//
//  User.swift
//  appPhoRent
//
//  Created by Александр Сетров on 31.03.2020.
//  Copyright © 2020 Александр Сетров. All rights reserved.
//

import Foundation

struct User{
    var name: String
    var email: String
    var password: String
    
}
